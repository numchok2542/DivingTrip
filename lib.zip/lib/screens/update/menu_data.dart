class Data {
  final String menu;
  final int id;

  Data({this.id, this.menu});
}

// Demo List of my works
List<Data> Datas = [
  Data(id: 1, menu: "Update hotel"),
  Data(id: 2, menu: "Update liveaboard"),
  Data(id: 3, menu: "Update trip"),
  Data(id: 4, menu: "Update boat"),
  Data(id: 5, menu: "Update staff"),
  Data(id: 6, menu: "Update dive master"),
];
