package mail

type ContentType uint8

const (
	PLAIN ContentType = iota
	HTML
)
